//
//  TableViewController.swift
//  LiveAPILogin
//
//  Created by Demo 01 on 03/03/23.
//  Copyright © 2023 scs. All rights reserved.
//

import UIKit


struct JsonModel:Decodable{
    var coursename: String
//    var duration: String
//    var fees: Int
//    var path:String
//    var url:String
    }

class TableViewController: UITableViewController {

    var arr = [JsonModel]()
    
  

    
        override func viewDidLoad() {
            super.viewDidLoad()
            getRequest()
            
        }
        // Do any additional setup after loading the view.
    func getRequest() {
        
        // request url
        let url = URL(string: "https://shivaconceptdigital.com/api/viewallcourse.php")! // change the url
        
        // create URLSession with default configuration
        let session = URLSession.shared
        
        // create dataTask using the session object to send data to the server
        let task = session.dataTask(with: url) { data, response, error in
            
            if let error = error {
                print("GET Request Error: \(error.localizedDescription)")
                return
            }
            
            // ensure there is valid response code returned from this HTTP response
            guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
                    print("Invalid Response received from the server")
                    return
            }
            
            // ensure there is data returned
            guard let responseData = data else {
                print("nil Data received from the server")
                return
            }
            
            do {
                // serialise the data object into Dictionary [String : Any]
                if let jsonResponse = try JSONSerialization.jsonObject(with: responseData, options: .mutableContainers) as? [String: Any] {
                    print(jsonResponse)
                } else {
                    print("data maybe corrupted or in wrong format")
                    throw URLError(.badServerResponse)
                }
            } catch let error {
                print("JSON Parsing Error: \(error.localizedDescription)")
            }
        }
        // resume the task
        task.resume()
    }
   
    
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = "\(arr[indexPath.row].coursename)"
        return cell
    }
    
}
    
    

